<?php
/*

Plugin Name: ICICI Woocommerce Payseal Plugin

Plugin URI: http://URI_Of_Page_Describing_Plugin_and_Updates

Description: This Plugin Integrates the ICICI Payseal Gateway to woocommerce

Version: 1.0

Author: andy

Author URI: http://facebook.com/anmolkarwal

License: A "Slug" license name e.g. GPL2

*/
// Include our Gateway Class and Register Payment Gateway with WooCommerce
if (!defined('ABSPATH')) exit;
add_action('plugins_loaded', 'icici_gateway');
function icici_gateway()
{
    if (!class_exists('WC_Payment_Gateway')) return;

    class WC_ICICI extends WC_Payment_Gateway
    {
        public function __construct()
        {
            // Go wild in here
            $this->id = 'icici_gt';
            $this->method_title = __('ICICI_siec', 'icici');
            $this->icon = plugins_url('images/logo.gif', __FILE__);
            $this->has_fields = FALSE;
            $this->init_form_fields();
            $this->init_settings();
            $this->title = $this->settings['title'];
            $this->description = $this->settings['description'];
            $this->enabled = $this->get_option('enabled');
            $this->liveurl = plugins_url('Payment Gateway') . '/icici/TestSsl.php';
            //     $this->notify_url = str_replace('https:', 'http:', home_url('/wc-api/WC_Mrova_Ccave'));
            $this->msg['message'] = "";
            $this->msg['class'] = "";
            add_action('woocommerce_update_options_payment_gateways_' . $this->id, array(
                $this,
                'admin_options'
            ));
            // $this->init_form_fields();
            // $this->init_settings();
        }

        function process_payment($order_id)
        {
            $order = new WC_Order($order_id);
            $total = $order->get_total();
            $redirect_url = NULL;
            global $woocommerce;
            #####################################################
            include(dirname(__FILE__) . "/icici/Sfa/BillToAddress.php");
            include(dirname(__FILE__) . "/icici/Sfa/CardInfo.php");
            include(dirname(__FILE__) . "/icici/Sfa/Merchant.php");
            include(dirname(__FILE__) . "/icici/Sfa/MPIData.php");
            include(dirname(__FILE__) . "/icici/Sfa/ShipToAddress.php");
            include(dirname(__FILE__) . "/icici/Sfa/PGResponse.php");
            include(dirname(__FILE__) . "/icici/Sfa/PostLibPHP.php");
            include(dirname(__FILE__) . "/icici/Sfa/PGReserveData.php"); //
            $oMPI = new     MPIData();
            $oCI = new    CardInfo();
            $oPostLibphp = new    PostLibPHP();
            $oPostLibphp->setMstrKeyDir(dirname(__FILE__) . '/icici/');
            $oPostLibphp->readPropFile();
            ///
            $oMerchant = new    Merchant();
            $oBTA = new    BillToAddress();
            $oSTA = new    ShipToAddress();
            $oPGResp = new    PGResponse();
            $oPGReserveData = new     PGReserveData();
            $oMerchant->setMerchantDetails("00215333", "00215333", "00215333", "10.10.10.238", rand() . "", "Ord134", SURL . "/wp-content/icici_gateway/icici/SFAResponse.php", "POST", "INR", "INV123", "req.Sale", $total, "", "Ext1", "true", "Ext3", "Ext4", "New PHP");
            $oBTA->setAddressDetails("CID", "Tester", "Aline1", "Aline2", "Aline3", "Pune", "A.P", "48927489", "IND", "tester@soft.com");
            $oSTA->setAddressDetails("Add1", "Add2", "Add3", "City", "State", "443543", "IND", "sad@df.com");
#$oMPI->setMPIRequestDetails("1245","12.45","356","2","2 shirts","12","20011212","12","0","","image/gif, image/x-xbitmap, image/jpeg, image/pjpeg, application/vnd.ms-powerpoint, application/vnd.ms-excel, application/msword, application/x-shockwave-flash, */*","Mozilla/4.0 (compatible; MSIE 5.5; Windows NT 5.0)");
            $oPGResp = $oPostLibphp->postSSL($oBTA, $oSTA, $oMerchant, $oMPI, $oPGReserveData);
            if ($oPGResp->getRespCode() == '000') {
                $redirect_url = $oPGResp->getRedirectionUrl();
                #$url =~ s/http/https/;
                #print "Location: ".$url."\n\n"; /**/
                #header("Location: ".$url);
                // redirect($url);
            } else {
                wc_add_notice($oPGResp->getRespMessage(), 'error');
                return (array('status' => 'false'));
            }
            ####################################################
            $order = new WC_Order($order_id);
            // Mark as on-hold (we're awaiting the cheque)
            $order->update_status('on-hold', __('Awaiting payment', 'woocommerce'));
            // Reduce stock levels
            //  $order->reduce_order_stock();
            // Remove cart
            //   $woocommerce->cart->empty_cart();
            // Return thankyou redirect
            return array(
                'result' => 'success',
                'redirect' => $redirect_url
            );
        }

        function init_form_fields()
        {
            $this->form_fields = array(
                'enabled' => array(
                    'title' => __('Enable/Disable', 'icici'),
                    'type' => 'checkbox',
                    'label' => __('Enable Cheque Payment', 'icici'),
                    'default' => 'yes'
                ),
                'title' => array(
                    'title' => __('Title', 'icici'),
                    'type' => 'text',
                    'description' => __('This controls the title which the user sees during checkout.', 'woocommerce'),
                    'default' => __('ICICI', 'icici')
                ),
                'description' => array(
                    'title' => __('Description', 'icici'),
                    'type' => 'textarea',
                    'description' => __('This controls the description which the user sees during checkout.', 'woocommerce'),
                    'default' => __("Pay via ICICI Payseal", 'woocommerce')
                )
            );
        }

        function admin_options()
        {
            // code to save options
            echo '<h3>' . __('CCAvenue Payment Gateway', 'icici') . '</h3>';
            echo '<p>' . __('CCAvenue is most popular payment gateway for online shopping in India') . '</p>';
            echo '<table class="form-table">';
            $this->generate_settings_html();
            echo '</table>';
        }
    }
}

function woocommerce_add_icici_gateway($methods)
{
    $methods[] = 'WC_ICICI';
    return $methods;
    print_r();
}

add_filter('woocommerce_payment_gateways', 'woocommerce_add_icici_gateway');

