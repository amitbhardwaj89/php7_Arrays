<?php

# This will remove all white space
#$oResp =~ s/\s*//g;
# $oPGResp->getResponse($oResp);
#print $oPGResp->getRespCode()."<br>";
#print $oPGResp->getRespMessage()."<br>";
#print $oPGResp->getTxnId()."<br>";
#print $oPGResp->getEpgTxnId()."<br>";
function redirect($url)
{
    if (headers_sent()) {
        ?>
        <html>
        <head>
            <script language="javascript" type="text/javascript">
                window.self.location = '<?php print($url);?>';
            </script>
        </head>
        </html>    <?php
        exit;
    } else {
        header("Location: " . $url);
        exit;
    }
}

?>